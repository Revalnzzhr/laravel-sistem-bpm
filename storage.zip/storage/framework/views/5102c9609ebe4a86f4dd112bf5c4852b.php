

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css">

    


    <?php
        $titles = [
            // 'kebijakan' => 'Kebijakan Peraturan',
            // 'eksternal' => 'Peraturan Eksternal',
            // 'instrument' => 'Instrumen APS',
        ];
    ?>

    



    <div class="d-flex flex-column min-vh-100 p-5 pt-0">
        

        <div class="ms-5 ps-3">
            <div style="display: flex; align-items: center;">
                <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;"
                    onclick="window.location.href='#'">&#x2039;</span>
                <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">
                    <?php if($type === 'kebijakan'): ?>
                        Dokumen Peraturan
                    <?php elseif($type === 'eksternal'): ?>
                        Dokumen Peraturan Eksternal
                    <?php elseif($type === 'instrument'): ?>
                        Instrument APS
                    <?php endif; ?>
                </h2>
            </div>
        </div>


        

        

        <div class="ms-5 ps-5">
            <a class="btn btn-primary" href="<?php echo e(url('/peraturan/' . request()->segment(2) . '/create')); ?>">Tambah
                Peraturan</a>
        </div>

        <div class="ms-5 p-5 pt-0 pb-0 my-3">
            
            <input type="text" name="query" class="form-control me-2" placeholder="Cari berdasarkan judul peraturan..."
                value="<?php echo e(request('query')); ?>">
            <button type="submit" class="btn btn-primary">Cari</button>
            </form>
        </div>



        <div class="table-container bg-white p-4 m-5 mt-0 rounded">
            <table class="table table-hover table-striped table-bordered text-center align-middle">
                <thead class="table-blue">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col" style="min-width: 200px;">Judul Peraturan</th>
                        <th scope="col">Nomor Induk</th>
                        <th scope="col" style="min-width: 150px;">Tanggal Berlaku</th>
                        <th scope="col" style="min-width: 150px;">Tanggal Kadaluarsa</th>
                        <th scope="col">File</th>
                        <th scope="col" style="min-width: 250px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $peraturan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td class="text-truncate" style="max-width: 300px;"><?php echo e($data->dok_judul ?? 'Tidak tersedia'); ?>

                            </td>
                            <td><?php echo e($data->dok_nomor_induk ?? 'Tidak tersedia'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->dok_tgl_berlaku)->locale('id')->translatedFormat('l, d F Y')); ?>

                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->dok_tgl_kadaluarsa)->locale('id')->translatedFormat('l, d F Y')); ?>

                            </td>
                            <td class="text-truncate" style="max-width: 300px;"><?php echo e($data->dok_file ?? 'Tidak tersedia'); ?>

                            <td>
                                <div class="d-flex justify-content-center gap-2 flex-wrap">
                                    <a href="<?php echo e(url('/peraturan/' . request()->segment(2) . '/' . $data->dok_id . '/show')); ?>"
                                        class="btn btn-success btn-sm">
                                        <i class="mdi mdi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(url('/peraturan/' . request()->segment(2) . '/' . $data->dok_id . '/edit')); ?>"
                                        class="btn btn-primary btn-sm">
                                        <i class="mdi mdi-pencil"></i>
                                    </a>
                                    <a href="<?php echo e(route('peraturan.upload', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        class="btn btn-info btn-sm">
                                        <i class="mdi mdi-upload"></i>
                                    </a>
                                    <a href="<?php echo e(route('peraturan.download', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        class="btn btn-warning btn-sm">
                                        <i class="mdi mdi-download"></i>
                                    </a>
                                    <a href="<?php echo e(route('peraturan.toggle', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        class="btn btn-secondary btn-sm"
                                        onclick="event.preventDefault(); document.getElementById('toggle-form-<?php echo e($data->dok_id); ?>').submit();">
                                        <i class="mdi mdi-toggle-switch"></i>
                                    </a>
                                    <form id="toggle-form-<?php echo e($data->dok_id); ?>"
                                        action="<?php echo e(route('peraturan.toggle', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                    </form>
                                    <a href="<?php echo e(route('peraturan.history', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        class="btn btn-dark btn-sm">
                                        <i class="fa fa-bars"></i>
                                    </a>
                                    <a href="<?php echo e(route('peraturan.historyDownload', ['type' => request()->segment(2), 'id' => $data->dok_id])); ?>"
                                        class="btn btn-secondary btn-sm">
                                        <i class="mdi mdi-clipboard-list"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Data tidak tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php $__env->startSection('scripts'); ?>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script>
                <?php if(session('success')): ?>
                    Swal.fire({
                        title: 'Berhasil!',
                        text: <?php echo json_encode(session('success'), 15, 512) ?>,
                        icon: 'success',
                        confirmButtonText: 'Tutup'
                    });
                <?php endif; ?>

                function confirmDelete(event, id) {
                    event.preventDefault(); // Mencegah pengiriman form secara langsung
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Data yang dihapus tidak dapat dikembalikan!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Ya, Hapus!',
                        cancelButtonText: 'Batal',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Jika konfirmasi di klik, kirimkan form penghapusan
                            document.getElementById(`delete-form-${id}`).submit();
                        }
                    });
                }
            </script>
        <?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/peraturan/index.blade.php ENDPATH**/ ?>