

<?php $__env->startSection('content'); ?>
<style>
    .preview-image {
        max-width: 100%;
        margin-top: 10px;
        display: none;
    }
</style>
<div class="d-flex flex-column min-vh-100 p-5 pt-0">
    <div class="ms-5 ps-3">
        <div style="display: flex; align-items: center;">
            <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;" onclick="window.location.href='/berita/read'">&#x2039;</span>
            <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">Kelola Berita</h2>
        </div>
    </div>

    <div class="shadow p-5 m-5 mt-3 bg-white rounded">
        <h2 class="mb-5" style="color: #5F5858; text-align: center;">Formulir Edit Berita</h2>
        <form method="POST" action="<?php echo e(route('berita.update', $berita->ber_id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="form-group mb-3">
                <label for="ber_judul" class="form-label fw-bold">Judul Berita</label>
                <input type="text" name="ber_judul" id="ber_judul" class="form-control" value="<?php echo e($berita->ber_judul); ?>" required>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group mb-3">
                        <label for="ber_tgl" class="form-label fw-bold">Tanggal Berita</label>
                        <input type="date" name="ber_tgl" id="ber_tgl" class="form-control" value="<?php echo e($berita->ber_tgl); ?>" required>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group mb-3">
                        <label for="ber_penulis" class="form-label fw-bold">Penulis</label>
                        <input type="text" name="ber_penulis" id="ber_penulis" class="form-control" value="<?php echo e($berita->ber_penulis); ?>" required>
                    </div>
                </div>
            </div>

            <div class="form-group mb-3">
                <label for="ber_isi" class="form-label fw-bold">Isi Berita</label>
                <textarea name="ber_isi" id="ber_isi" class="form-control" rows="5"><?php echo e($berita->ber_isi); ?></textarea>
            </div>

            <div class="row">
                <?php $__currentLoopData = range(1, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <label for="ber_foto<?php echo e($index); ?>" class="form-label fw-bold">Foto <?php echo e($index); ?></label>
                    <div class="border p-2 text-center" style="min-width: 150px; min-height: 200px;">
                        <?php if($berita["ber_foto$index"]): ?>
                        <img id="preview<?php echo e($index); ?>" src="<?php echo e(asset('storage/' . $berita["ber_foto$index"])); ?>" class="img-fluid img-thumbnail" alt="Foto <?php echo e($index); ?>" style="max-height: 200px;">
                        <?php else: ?>
                        <img id="preview<?php echo e($index); ?>" class="img-fluid img-thumbnail" alt="Preview Foto <?php echo e($index); ?>" style="max-height: 200px; display: none;">
                        <p id="placeholder<?php echo e($index); ?>" class="text-muted m-0">Tidak ada foto yang dipilih</p>
                        <?php endif; ?>
                    </div>
                    <input type="file" name="ber_foto<?php echo e($index); ?>" id="ber_foto<?php echo e($index); ?>" class="form-control mt-2" accept="image/*">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row mt-4">
                <div class="col-lg-6">
                    <button type="submit" class="btn btn-primary w-100">Perbarui</button>
                </div>
                <div class="col-lg-6">
                    <a href="<?php echo e(route('berita.read')); ?>" class="btn btn-danger w-100">Batal</a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        CKEDITOR.replace('ber_isi', {
            toolbar: [{
                    name: 'basicstyles',
                    items: ['Bold', 'Italic', 'Underline']
                },
                {
                    name: 'paragraph',
                    items: ['NumberedList', 'BulletedList']
                },
                {
                    name: 'links',
                    items: ['Link']
                }
            ]
        });

        const previewImages = [1, 2, 3].map(index => ({
            input: document.getElementById(`ber_foto${index}`),
            preview: document.getElementById(`preview${index}`),
            placeholder: document.getElementById(`placeholder${index}`)
        }));

        previewImages.forEach(({
            input,
            preview,
            placeholder
        }) => {
            input.addEventListener('change', () => {
                const file = input.files[0];
                if (file) {
                    preview.src = URL.createObjectURL(file);
                    preview.style.display = 'block';
                    placeholder.style.display = 'none';
                } else {
                    preview.style.display = 'none';
                    placeholder.style.display = 'block';
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\laravel-sistem-bpm\resources\views/berita/edit.blade.php ENDPATH**/ ?>