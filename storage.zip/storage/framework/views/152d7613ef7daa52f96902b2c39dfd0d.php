

<?php $__env->startSection('content'); ?>
<style>
    .preview-image {
        max-width: 100%;
        margin-top: 10px;
        display: none;
    }
</style>
<div class="d-flex flex-column min-vh-100 p-5 pt-0">
    <div class="ms-5 ps-3">
        <div style="display: flex; align-items: center;">
            <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;" onclick="window.location.href='/kegiatan/dokumentasi/read'">&#x2039;</span>
            <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">Edit Dokumentasi Kegiatan</h2>
        </div>
    </div>

    <div class="shadow p-5 m-5 mt-3 bg-white rounded">
        <h2 class="mb-5" style="color: #5F5858; text-align: center;">Formulir Dokumentasi Kegiatan</h2>
        <form method="POST" action="<?php echo e(route('dokumentasiKegiatan.update', $kegiatan->keg_id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-3">
                <label for="keg_nama" class="form-label fw-bold">Nama Kegiatan</label>
                <input type="text" name="keg_nama" id="keg_nama" class="form-control" value="<?php echo e(old('keg_nama', $kegiatan->keg_nama)); ?>" required>
                <?php $__errorArgs = ['keg_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group mb-3">
                        <label for="jkg_id" class="form-label fw-bold">Jenis Kegiatan</label>
                        <select name="jkg_id" id="jkg_id" class="form-control" required>
                            <option value="">-- Pilih Jenis Kegiatan --</option>
                            <?php $__currentLoopData = $jenisKegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis->jkg_id); ?>" <?php echo e(old('jkg_id', $kegiatan->jkg_id) == $jenis->jkg_id ? 'selected' : ''); ?>>
                                <?php echo e($jenis->jkg_nama); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['jkg_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="keg_tgl_mulai" class="form-label fw-bold">Tanggal Mulai</label>
                        <input type="date" name="keg_tgl_mulai" id="keg_tgl_mulai" class="form-control" value="<?php echo e(old('keg_tgl_mulai', $kegiatan->keg_tgl_mulai)); ?>" required>
                        <?php $__errorArgs = ['keg_tgl_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="keg_jam_mulai" class="form-label fw-bold">Waktu Mulai</label>
                        <input type="time" name="keg_jam_mulai" id="keg_jam_mulai" class="form-control" value="<?php echo e(old('keg_jam_mulai', $kegiatan->keg_jam_mulai)); ?>" required>
                        <?php $__errorArgs = ['keg_jam_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group mb-3">
                        <label for="keg_tempat" class="form-label fw-bold">Tempat</label>
                        <input type="text" name="keg_tempat" id="keg_tempat" class="form-control" value="<?php echo e(old('keg_tempat', $kegiatan->keg_tempat)); ?>" required>
                        <?php $__errorArgs = ['keg_tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="keg_tgl_selesai" class="form-label fw-bold">Tanggal Selesai</label>
                        <input type="date" name="keg_tgl_selesai" id="keg_tgl_selesai" class="form-control" value="<?php echo e(old('keg_tgl_selesai', $kegiatan->keg_tgl_selesai)); ?>" required>
                        <?php $__errorArgs = ['keg_tgl_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="keg_jam_selesai" class="form-label fw-bold">Waktu Selesai</label>
                        <input type="time" name="keg_jam_selesai" id="keg_jam_selesai" class="form-control" value="<?php echo e(old('keg_jam_selesai', $kegiatan->keg_jam_selesai)); ?>" required>
                        <?php $__errorArgs = ['keg_jam_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="form-group mb-3">
                <label for="keg_deskripsi" class="form-label fw-bold">Deskripsi Singkat</label>
                <textarea name="keg_deskripsi" id="keg_deskripsi" class="form-control" rows="5" required><?php echo e(old('keg_deskripsi', $kegiatan->keg_deskripsi)); ?></textarea>
                <?php $__errorArgs = ['keg_deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group mb-3">
                        <label for="keg_link_folder" class="form-label fw-bold">Link Folder Kegiatan</label>
                        <input type="text" name="keg_link_folder" id="keg_link_folder" class="form-control" value="<?php echo e(old('keg_link_folder', $kegiatan->keg_link_folder)); ?>" required>
                        <?php $__errorArgs = ['keg_link_folder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="keg_dok_notulen" class="form-label fw-bold">File Notulensi</label>
                        <input
                        type="file"
                        name="keg_dok_notulen"
                        id="keg_dok_notulen"
                        class="form-control"
                        accept=".pdf,.doc,.docx,.xls,.xlsx">
                        <?php $__errorArgs = ['keg_dok_notulen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <sub>

                            Berkas saat ini:
                            <a
                                href="<?php echo e(asset('storage/' . $kegiatan->keg_dok_notulen)); ?>"
                                className="text-decoration-none"
                                target="_blank"
                                rel="noopener noreferrer">
                                [Unduh Berkas]
                            </a>
                            <br />
                            Unggah ulang jika ingin mengganti berkas yang sudah ada
                        </sub>
                    </div>

                    <div class="form-group mb-3">
                        <label for="keg_status_dok_notulen" class="form-label fw-bold">Status Dokumen</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input 
                                    class="form-check-input" 
                                    type="radio" 
                                    name="keg_status_dok_notulen" 
                                    id="privat" 
                                    value="Privat" 
                                    <?php echo e(old('keg_status_dok_notulen', $kegiatan->keg_status_dok_notulen) == 'Privat' ? 'checked' : ''); ?> 
                                    required>
                                <label class="form-check-label" for="privat">
                                    Privat
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input 
                                    class="form-check-input" 
                                    type="radio" 
                                    name="keg_status_dok_notulen" 
                                    id="publik" 
                                    value="Publik" 
                                    <?php echo e(old('keg_status_dok_notulen', $kegiatan->keg_status_dok_notulen) == 'Publik' ? 'checked' : ''); ?> 
                                    required>
                                <label class="form-check-label" for="publik">
                                    Publik
                                </label>
                            </div>
                            <?php $__errorArgs = ['keg_status_dok_notulen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="border p-2 text-center" style="min-width: 150px; min-height: 200px;">
                        <!-- Gambar preview -->
                        <img 
                            id="preview" 
                            class="img-fluid img-thumbnail"  
                            src="<?php echo e($kegiatan->keg_foto_sampul ? asset('storage/' . $kegiatan->keg_foto_sampul) : ''); ?>" 
                            alt="Preview Foto" 
                            style="max-height: 200px; <?php echo e($kegiatan->keg_foto_sampul ? 'display: block;' : 'display: none;'); ?>">
                        <!-- Teks jika tidak ada foto -->
                        <p id="placeholder" class="text-muted m-0" style="<?php echo e($kegiatan->keg_foto_sampul ? 'display: none;' : 'display: block;'); ?>">
                            Tidak ada foto yang dipilih
                        </p>
                    </div>
                    <!-- Input file -->
                    <input type="file" name="keg_foto_sampul" id="keg_foto_sampul" class="form-control mt-2" accept="image/*">
                </div>

            </div>


           
            <div class="row mt-4">
                <div class="col-lg-6">
                    <button type="submit" class="btn btn-primary w-100">Perbarui</button>
                </div>
                <div class="col-lg-6">
                    <a href="<?php echo e(route('jadwalKegiatan.read')); ?>" class="btn btn-danger w-100">Batal</a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const imgInp = document.getElementById('keg_foto_sampul');
        const previewImg = document.getElementById('preview');
        const placeholderText = document.getElementById('placeholder');

        // Fungsi untuk memperbarui preview
        const updatePreview = (file) => {
            if (file) {
                previewImg.src = URL.createObjectURL(file);
                previewImg.style.display = 'block';
                placeholderText.style.display = 'none';
            } else {
                previewImg.style.display = 'none';
                placeholderText.style.display = 'block';
            }
        };

        // Event listener untuk perubahan input file
        imgInp.addEventListener('change', () => {
            const files = imgInp.files;
            if (files && files[0]) {
                updatePreview(files[0]); // Tampilkan gambar baru
            }
        });


        <?php if(session('error')): ?>
        Swal.fire({
            title: 'Gagal!',
            text: <?php echo json_encode(session('error'), 15, 512) ?>,
            icon: 'error',
            confirmButtonText: 'Tutup'
        });
        <?php endif; ?>

        <?php if(session('success')): ?>
        Swal.fire({
            title: 'Berhasil!',
            text: <?php echo json_encode(session('success'), 15, 512) ?>,
            icon: 'success',
            confirmButtonText: 'Tutup'
        });
        <?php endif; ?>

        CKEDITOR.replace('keg_deskripsi', {
            toolbar: [{
                    name: 'basicstyles',
                    items: ['Bold', 'Italic', 'Underline']
                },
                {
                    name: 'paragraph',
                    items: ['NumberedList', 'BulletedList']
                },
                {
                    name: 'links',
                    items: ['Link']
                }
            ]
        });
       
        
    });




</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/dokumentasiKegiatan/edit.blade.php ENDPATH**/ ?>