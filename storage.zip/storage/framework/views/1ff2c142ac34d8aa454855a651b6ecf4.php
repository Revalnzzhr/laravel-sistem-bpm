

<?php $__env->startSection('content'); ?>
    <style>
        .preview-image {
            max-width: 100%;
            margin-top: 10px;
            display: none;
        }
    </style>
    <div class="d-flex flex-column min-vh-100 p-5 pt-0">
        <div class="ms-5 ps-3">
            <div style="display: flex; align-items: center;">
                <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;"
                    onclick="redirectToParentURL()">
                    &#x2039;
                </span>
                <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">Kelola Peraturan</h2>
            </div>
        </div>

        <div class="shadow p-5 m-5 mt-3 bg-white rounded">
            <h2 class="mb-5" style="color: #5F5858; text-align: center;">Formulir Unggah Peraturan</h2>


            <div class="form-group mb-3">
                <label for="dok_nomor_induk" class="form-label fw-bold">Nomor Induk Dokumen</label>
                <input type="text" name="dok_nomor_induk" id="dok_nomor_induk" class="form-control"
                    value="<?php echo e($peraturan->dok_nomor_induk); ?>" readonly>
            </div>

            <div class="form-group mb-3">
                <label for="dok_judul" class="form-label fw-bold">Judul Peraturan</label>
                <input type="text" name="dok_judul" id="dok_judul" class="form-control"
                    value="<?php echo e($peraturan->dok_judul); ?>" readonly>
            </div>

            <div class="form-group mb-3">
                <label for="dok_tgl_berlaku" class="form-label fw-bold">Tahun Dokumen</label>
                <input type="date" name="dok_tgl_berlaku" id="dok_tgl_berlaku" class="form-control"
                    value="<?php echo e($peraturan->dok_tgl_berlaku); ?>" readonly>
            </div>

            <div class="form-group mb-3">
                <label for="dok_control" class="form-label fw-bold">Control Type</label>
                <input type="text" name="dok_control" id="dok_control" class="form-control"
                    value="<?php echo e($peraturan->dok_control); ?>" readonly>
            </div>

            <div class="form-group mb-3">
                <label for="dok_tgl_kadaluarsa" class="form-label fw-bold">Tahun Kadaluarsa</label>
                <input type="date" name="dok_tgl_kadaluarsa" id="dok_tgl_kadaluarsa" class="form-control"
                    value="<?php echo e($peraturan->dok_tgl_kadaluarsa); ?>" readonly>
            </div>

            <form method="POST" action="<?php echo e(route('peraturan.updateFile', ['type' => $type, 'id' => $peraturan->dok_id])); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group mb-4">
                    <label for="dok_file" class="form-label fw-bold">Unggah Dokumen</label>
                    <input type="file" name="dok_file" id="dok_file" class="form-control" accept="file/*"
                        value="<?php echo e($peraturan->dok_control); ?>">
                </div>

                <div class="row mt-4">
                    <div class="col-lg-6">
                        <button type="submit" class="btn btn-primary w-100">Simpan</button>
                    </div>
                    <div class="col-lg-6">
                        <a href="<?php echo e(url('/peraturan/' . request()->segment(2))); ?>" class="btn btn-danger w-100">Batal</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
    
    <script>
        function redirectToParentURL() {
            // Ambil URL saat ini
            const currentURL = window.location.pathname;

            // Hilangkan segment terakhir (/3/show)
            const parentURL = currentURL.split('/').slice(0, -2).join('/');

            // Redirect ke URL induk
            window.location.href = parentURL;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/peraturan/unggah.blade.php ENDPATH**/ ?>