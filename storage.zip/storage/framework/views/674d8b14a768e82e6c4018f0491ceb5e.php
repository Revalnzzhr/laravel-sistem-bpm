

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css">

    


    <?php
        $titles = [
            // 'kebijakan' => 'Kebijakan Peraturan',
            // 'eksternal' => 'Peraturan Eksternal',
            // 'instrument' => 'Instrumen APS',
        ];
    ?>

    



    <div class="d-flex flex-column min-vh-100 p-5 pt-0">
        <div class="ms-5 ps-3">
            <div style="display: flex; align-items: center;">
                <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;"
                    onclick="redirectToParentURL()">
                    &#x2039;
                </span>
                <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">
                    <?php if($type === 'kebijakan'): ?>
                        Dokumen Peraturan
                    <?php elseif($type === 'eksternal'): ?>
                        Dokumen Peraturan Eksternal
                    <?php elseif($type === 'instrument'): ?>
                        Instrument APS
                    <?php endif; ?>
                </h2>
            </div>
        </div>


        <div class="table-container bg-white p-3 ps-5 m-5 mt-0 rounded">
            <table class="table table-hover table-striped table-bordered">
                <thead style="text-align: center;">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Tanggal Unduh</th>
                        <th scope="col">Judul Dokumen</th>
                        <th scope="col">Nama Berkas (File)</th>
                        <th scope="col">Jenis Penyalinan</th>
                        <th scope="col">Nama Pengunduh</th>
                        <th scope="col">Jabatan</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($i++); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->udo_tgl_unduh)->format('d M Y H:i')); ?></td>
                            <td><?php echo e($data->dok_judul); ?></td>
                            <td>
                                <?php if($data->dok_file): ?>
                                    <a href="<?php echo e(asset('storage/' . $data->dok_file)); ?>" target="_blank">
                                        <?php echo e(basename($data->dok_file)); ?>

                                    </a>
                                <?php else: ?>
                                    Tidak Ada File
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->udo_jenis_penyalinan); ?></td>
                            <td><?php echo e($data->udo_created_by); ?></td>
                            <td>-</td>
                            <td><?php echo e($data->udo_status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Data tidak tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <?php $__env->startSection('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            <?php if(session('success')): ?>
                Swal.fire({
                    title: 'Berhasil!',
                    text: <?php echo json_encode(session('success'), 15, 512) ?>,
                    icon: 'success',
                    confirmButtonText: 'Tutup'
                });
            <?php endif; ?>

            function confirmDelete(event, id) {
                event.preventDefault(); // Mencegah pengiriman form secara langsung
                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Data yang dihapus tidak dapat dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, Hapus!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Jika konfirmasi di klik, kirimkan form penghapusan
                        document.getElementById(`delete-form-${id}`).submit();
                    }
                });
            }
        </script>
        <script>
            function redirectToParentURL() {
                // Ambil URL saat ini
                const currentURL = window.location.pathname;

                // Hilangkan segment terakhir (/3/show)
                const parentURL = currentURL.split('/').slice(0, -2).join('/');

                // Redirect ke URL induk
                window.location.href = parentURL;
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/peraturan/historyDownload.blade.php ENDPATH**/ ?>