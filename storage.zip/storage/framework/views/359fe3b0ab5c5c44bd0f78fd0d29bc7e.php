<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css">

<style>
    .keg-item .nav-link {
            color:rgb(170, 200, 252);
        }

        /* Nav Desktop View */
        @media (min-width: 1200px) {
            .nav .keg-item {
                margin-right: 15px;
            }


            .keg-item:hover {
               
                background-color: #2654A1;
                border-radius: 12px;
                
            }
        }
</style>
<div class="container mt-4 mb-5">
    <div class="text-center mb-4">
        <h2 style="color:#2654A1; font-size: 1.8rem; font-weight: 700;">
            Dokumentasi Kegiatan <br /> Badan Penjamin Mutu (BPM)
        </h2>
    </div>

    <?php if(Cookie::has('username')): ?>
    <div class="d-flex justify-content-end mb-3">
        <a class="btn btn-primary" href="<?php echo e(route('dokumentasiKegiatan.read')); ?>">Kelola Dokumentasi Kegiatan</a>
    </div>
    <?php endif; ?>

    <!-- Tabs for Jenis Kegiatan -->
    <ul class="nav nav-tabs mb-3" id="jenisKegiatanTabs" role="tablist">
        <?php $__currentLoopData = $jenisKegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="keg-item" style="color:black !important;" role="presentation">
                <button class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" id="tab-<?php echo e($jenis->jkg_id); ?>" data-bs-toggle="tab" data-bs-target="#content-<?php echo e($jenis->jkg_id); ?>" type="button" role="tab" aria-controls="content-<?php echo e($jenis->jkg_id); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                    <?php echo e($jenis->jkg_nama); ?>

                </button>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="tab-content" id="jenisKegiatanContent">
        <?php $__currentLoopData = $jenisKegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="content-<?php echo e($jenis->jkg_id); ?>" role="tabpanel" aria-labelledby="tab-<?php echo e($jenis->jkg_id); ?>">
            <?php
                // Filter kegiatan berdasarkan jenis kegiatan ID
                $filteredKegiatan = $kegiatan->where('jkg_id', $jenis->jkg_id);

                // Group kegiatan berdasarkan tahun
                $kegiatanPerTahun = $filteredKegiatan->groupBy(function($item) {
                    return \Carbon\Carbon::parse($item->keg_tgl_mulai)->format('Y');
                });
            ?>

            <!-- Jika tidak ada kegiatan -->
            <?php if($filteredKegiatan->isEmpty()): ?>
                <p class="text-center mt-3">Data tidak ada</p>
            <?php else: ?>
                <div class="accordion" id="accordion-<?php echo e($jenis->jkg_id); ?>">
                    <?php $__currentLoopData = $kegiatanPerTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun => $kegiatanList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading-<?php echo e($jenis->jkg_id); ?>-<?php echo e($tahun); ?>">
                            <button class="accordion-button <?php if(!$loop->first): ?> collapsed <?php endif; ?>" type="button" data-bs-toggle   ="collapse" data-bs-target="#collapse-<?php echo e($jenis->jkg_id); ?>-<?php echo e($tahun); ?>" aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>" aria-controls="collapse-<?php echo e($jenis->jkg_id); ?>-<?php echo e($tahun); ?>">
                                <?php echo e($tahun); ?>

                            </button>
                        </h2>
                        <div id="collapse-<?php echo e($jenis->jkg_id); ?>-<?php echo e($tahun); ?>" class="accordion-collapse collapse <?php if($loop->first): ?> show <?php endif; ?>" aria-labelledby="heading-<?php echo e($jenis->jkg_id); ?>-<?php echo e($tahun); ?>" data-bs-parent="#accordion-<?php echo e($jenis->jkg_id); ?>">
                            <div class="accordion-body">
                                <div class="row">
                                    <?php $__currentLoopData = $kegiatanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatanItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-4">
                                        <div class="card">
                                            <img src="<?php echo e(asset('storage/' . $kegiatanItem->keg_foto_sampul)); ?>" class="card-img-top" alt="<?php echo e($kegiatanItem->keg_nama); ?>">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($kegiatanItem->keg_nama); ?></h5>
                                                <p class="card-text">
                                                    <strong><?php echo e(\Carbon\Carbon::parse($kegiatanItem->keg_tgl_mulai)->format('l, d F Y')); ?></strong><br>
                                                    <?php echo e(\Carbon\Carbon::parse($kegiatanItem->keg_jam_mulai)->format('H:i')); ?> WIB - <?php echo e(\Carbon\Carbon::parse($kegiatanItem->keg_jam_selesai)->format('H:i')); ?> WIB<br>
                                                    <strong>Tempat:</strong> <?php echo e($kegiatanItem->keg_tempat); ?>

                                                </p>
                                                <a href="<?php echo e($kegiatanItem->keg_link_folder); ?>" class="btn btn-primary btn-sm" target="_blank">Galeri Selengkapnya</a>
                                                <?php if($kegiatanItem->keg_status_dok_notulen === 'ada'): ?>
                                                <a href="<?php echo e(asset('storage/' . $kegiatanItem->keg_dok_notulen)); ?>" class="btn btn-danger btn-sm" target="_blank">File Notulen</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/dokumentasiKegiatan/index.blade.php ENDPATH**/ ?>