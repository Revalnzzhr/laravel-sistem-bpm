

<?php $__env->startSection('content'); ?>
<style>
    #preview {
        max-width: 100%;
        margin-top: 10px;
        display: none;
    }
</style>
<div class="d-flex flex-column min-vh-100 p-5 pt-0">
    <div class="ms-5 ps-3">
        <div style="display: flex; align-items: center;">
            <span style="color: #2654A1; font-size: 5rem; margin-right: 10px; cursor: pointer;" onclick="window.location.href='/tentang/read'">&#x2039;</span>
            <h2 style="color: #2654A1; margin: 0; padding-top:1rem;">Kelola Tentang</h2>
        </div>
    </div>

    <div class="shadow p-5 m-5 mt-3 bg-white rounded">
        <h2 class="mb-5" style="color: #5F5858; text-align: center;">Formulir Tentang</h2>
        <form action="<?php echo e(route('tentang.update', $tentang->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="form-group mb-3">
                <label for="ten_category" class="form-label fw-bold">Kategori</label>
                <input type="text" name="ten_category" id="ten_category" class="form-control" value="<?php echo e(old('ten_category', $tentang->ten_category)); ?>" required>
            </div>

            <div class="form-group">
                <label for="ten_isi" class="form-label fw-bold">Isi</label>
                <?php if ($tentang->id == 7): ?>
                    <div>
                        <!-- Input file untuk gambar -->
                        <input
                            type="file"
                            class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ten_isi"
                            accept="image/*"
                            id="imgInp">

                        <!-- Container untuk pratinjau gambar -->
                        <div class="preview-container">
                            <img
                                id="blah"
                                class="preview-image"
                                src="<?= !empty($tentang->ten_isi) ? asset('storage/tentang/' . $tentang->ten_isi) : '' ?>"
                                alt="Preview Image"
                                style="max-width: 100%; margin-top: 10px; <?= !empty($tentang->ten_isi) ? 'display: block;' : 'display: none;' ?>">
                            <p class="preview-text" style="<?= !empty($tentang->ten_isi) ? 'display: none;' : 'display: block;' ?>">Your image preview will appear here.</p>
                        </div>

                        <!-- Menampilkan pesan error jika ada -->
                        <?php $__errorArgs = ['ten_isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php elseif ($tentang->id == 8): ?>
                    <input
                        type="file"
                        name="ten_isi"
                        id="ten_isi"
                        class="form-control"
                        accept=".pdf,.doc,.docx,.xls,.xlsx">
                    <sub>

                        Berkas saat ini:
                        <a
                            href="<?php echo e(asset('storage/tentang/' . $tentang->ten_isi)); ?>"
                            className="text-decoration-none"
                            target="_blank"
                            rel="noopener noreferrer">
                            [Unduh Berkas]
                        </a>
                        <br />
                        Unggah ulang jika ingin mengganti berkas yang sudah ada
                    </sub>
                <?php else: ?>
                    <textarea
                        name="ten_isi"
                        id="ten_isi"
                        class="form-control"
                        rows="5"
                        required><?= htmlspecialchars($tentang->ten_isi) ?></textarea>
                <?php endif; ?>
            </div>


            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <button
                        type="submit"
                        class="btn btn-primary mt-3"
                        style="width: 100%;">
                        Update
                    </button>
                </div>
                <div class="col-lg-6 col-md-6">
                    <a
                        href="<?php echo e(route('tentang.read')); ?>"
                        class="btn btn-danger mt-3"
                        style="width: 100%;">
                        Batal
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 CDN -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const tenIsi = document.getElementById('ten_isi');
        const imgInp = document.getElementById('imgInp');
        const blah = document.getElementById('blah');
        const previewText = document.querySelector('.preview-text');
        const form = document.getElementById('tentangForm');




        // Hanya aktifkan CKEditor jika elemen adalah textarea
        if (tenIsi && tenIsi.tagName === 'TEXTAREA') {
            CKEDITOR.replace('ten_isi', {
                toolbar: [{
                        name: 'basicstyles',
                        items: ['Bold', 'Italic', 'Underline']
                    },
                    {
                        name: 'lists',
                        items: ['NumberedList', 'BulletedList']
                    },
                    {
                        name: 'links',
                        items: ['Link']
                    }
                ]
            });

            form.addEventListener('submit', (e) => {
                // Salin data CKEditor ke dalam textarea sebelum submit
                console.log("jalan")
                tenIsi.value = CKEDITOR.instances.ten_isi.getData();

                // Menambahkan SweetAlert sebelum submit
                e.preventDefault(); // Cegah pengiriman form secara default

                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Anda ingin memperbarui data ini?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, perbarui!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit(); // Jika ya, submit formulir
                    }
                });
            });
        }





        imgInp.addEventListener('change', (evt) => {
            const [file] = imgInp.files;
            if (file) {
                blah.src = URL.createObjectURL(file);
                blah.style.display = 'block';
                previewText.style.display = 'none';
            } else {
                blah.style.display = 'none';
                previewText.style.display = 'block';
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PRG5_2024_MIA\PROJEK\git-laravel\laravel-sistem-bpm\resources\views/tentang/edit.blade.php ENDPATH**/ ?>